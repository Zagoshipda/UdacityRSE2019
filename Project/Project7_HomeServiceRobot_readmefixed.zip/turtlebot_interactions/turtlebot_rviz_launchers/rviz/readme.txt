
===== Filename Extensions =====

 * .vcg  : fuerte
 * .rviz : groovy
